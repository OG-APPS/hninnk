from __future__ import annotations
class Permissions:
    def __init__(self, d): self.d=d
    def dismiss_popups(self):
        # Example selectors could be added here
        pass
