from __future__ import annotations
import time, random, subprocess
from typing import Dict, Any, List
from loguru import logger
from interfaces.ui2 import connect
from core.state_machine import StateMachine

TIKTOK_PACKAGES = [
    "com.zhiliaoapp.musically",
    "com.ss.android.ugc.trill",
    "com.ss.android.ugc.aweme",
]

class DeviceRunner:
    def __init__(self, serial: str):
        self.serial = serial
        logger.info(f"Connecting to {serial}")
        self.d = connect(serial)
        self.sm = StateMachine(serial, self.d)

    def wake_and_unlock(self):
        try:
            if not self.d.screen_on():
                self.d.screen_on(); time.sleep(0.8)
            self.d.unlock()
        except Exception:
            try:
                subprocess.run(["adb","-s",self.serial,"shell","input","keyevent","224"])
                time.sleep(0.4)
                subprocess.run(["adb","-s",self.serial,"shell","swipe","400","1200","400","300","200"])
            except Exception as e:
                logger.warning(f"Unlock fallback failed: {e}")

    def start_tiktok(self):
        pkg = TIKTOK_PACKAGES[0]
        for p in TIKTOK_PACKAGES:
            try:
                if self.d.app_info(p): pkg=p; break
            except Exception: pass
        logger.info(f"Starting TikTok package {pkg}")
        self.d.app_start(pkg, use_monkey=True); time.sleep(2.0)

    def warmup(self, seconds: int = 60) -> bool:
        self.wake_and_unlock(); self.start_tiktok()
        self.sm.warmup(seconds=seconds, like_prob=0.07)
        return True

    def post_video(self, video_path: str, caption: str = "") -> bool:
        logger.info(f"Posting video: {video_path} (caption len={len(caption)})")
        time.sleep(2.0)
        return True

    def run_pipeline(self, payload: Dict[str, Any]) -> bool:
        steps: List[Dict[str, Any]] = payload.get("steps", [])
        repeat = int(payload.get("repeat", 1))
        lo, hi = payload.get("sleep_between", [2,5])
        ok=True
        for _ in range(repeat):
            for st in steps:
                t = st.get("type")
                if t=="warmup":
                    ok = self.warmup(int(st.get("duration",60))) and ok
                elif t=="break":
                    time.sleep(int(st.get("duration",60)))
                elif t=="post_video":
                    vp = st.get("video",""); cap = st.get("caption","")
                    ok = self.post_video(vp, cap) and ok
                elif t=="rotate_identity":
                    logger.info("Rotate identity (soft): clear + restart app"); time.sleep(2.0)
                else:
                    logger.warning(f"Unknown step: {t}")
                time.sleep(random.uniform(lo,hi))
        return ok
