## UX decisions
- Sidebar navigation with big hit targets.
- Quick Run wizard simplified: goal, content, safety, run.
- Jobs table with Cancel/Retry; Logs tab aggregates API/worker/scheduler.
- scrcpy controls in Overview; optional auto-open in Quick Run.
- Consistent spacing, font sizes, dark theme with high contrast.
