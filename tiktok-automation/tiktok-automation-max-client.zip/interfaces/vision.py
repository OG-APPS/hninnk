from __future__ import annotations
# Stub for future OpenCV-based template matches or text checks
def is_on_feed(frame=None) -> bool:
    return True
