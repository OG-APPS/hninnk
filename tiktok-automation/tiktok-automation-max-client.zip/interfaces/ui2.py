from __future__ import annotations
import uiautomator2 as u2
from loguru import logger

def connect(serial: str):
    logger.info(f"UI2 connecting: {serial}")
    d = u2.connect(serial)
    try: d.healthcheck()
    except Exception: pass
    return d
