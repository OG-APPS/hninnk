from __future__ import annotations
import time, requests, os, json
from loguru import logger
from utils.logger_setup import setup_logger
from core.device_runner import DeviceRunner

API = os.environ.get("API_URL", "http://127.0.0.1:8000")
DEVICE = os.environ.get("DEVICE_SERIAL", "")

def run():
    setup_logger("worker")
    if not DEVICE:
        logger.error("DEVICE_SERIAL not set")
        return
    dr = DeviceRunner(DEVICE)
    logger.info(f"Worker starting for device {DEVICE}")
    while True:
        try:
            r = requests.get(f"{API}/jobs", params={"device": DEVICE, "status": "next"}, timeout=10)
            r.raise_for_status()
            jobs = r.json()
            if not jobs:
                time.sleep(1.0); continue
            j = jobs[0]
            jid = j["id"]; jtype = j["type"]; payload = json.loads(j["payload"] or "{}")
            ok = True
            logger.info(f"Running job {jid} type={jtype}")
            if jtype == "warmup":
                secs = int(payload.get("seconds", 60))
                ok = dr.warmup(seconds=secs)
            elif jtype == "pipeline":
                ok = dr.run_pipeline(payload)
            else:
                logger.warning(f"Unknown job type: {jtype}"); ok = False
            try:
                requests.post(f"{API}/jobs/{jid}/complete", params={"ok": ok}, timeout=10)
            except Exception as e:
                logger.warning(f"Could not notify completion: {e}")
        except Exception as e:
            logger.error(f"Loop error: {e}"); time.sleep(2.0)

if __name__ == "__main__": run()
