from __future__ import annotations
import time, os, requests
from apscheduler.schedulers.background import BackgroundScheduler
from loguru import logger
from utils.logger_setup import setup_logger
from utils.config import load_config

API = os.environ.get("API_URL", "http://127.0.0.1:8000")

def enqueue_cycle(device: str, cycle_steps, repeat=1):
    try:
        r=requests.post(f"{API}/enqueue/pipeline", json={
            "device_serial": device,
            "steps": cycle_steps,
            "repeat": repeat,
            "sleep_between": [2,5]
        }, timeout=10)
        logger.info(f"Enqueue cycle status={r.status_code}")
    except Exception as e:
        logger.error(f"enqueue error: {e}")

def build_cycle(config, name: str):
    cycles = config.get("cycles", {})
    c = cycles.get(name)
    if not c: return []
    steps = c.get("steps", [])
    return steps

def schedule_jobs(sched: BackgroundScheduler, cfg):
    device = cfg.get("system", {}).get("default_device", "")
    schedules = cfg.get("schedules", {})
    # Simple strategy: run every N minutes based on items, demo purposes
    for sname, sdata in schedules.items():
        items = sdata.get("items", [])
        repeat = int(sdata.get("repeat", 1))
        def run_schedule(items=items, device=device, repeat=repeat, cfg=cfg):
            logger.info(f"Running schedule: {sname}")
            for it in items:
                t = it.get("type")
                if t=="cycle":
                    steps = build_cycle(cfg, it.get("name",""))
                    enqueue_cycle(device, steps, repeat=1)
                elif t=="break":
                    mins = int(it.get("minutes", 10))
                    logger.info(f"Schedule break {mins} min")
                    time.sleep(mins*60)
        # Every hour for demo; in production, replace with cron-like config
        sched.add_job(run_schedule, "interval", minutes=60, id=f"sched_{sname}", replace_existing=True)

def run_scheduler_loop():
    setup_logger("scheduler")
    cfg = load_config()
    logger.info("Scheduler loop started (add jobs via API/CLI).")
    sched = BackgroundScheduler()
    schedule_jobs(sched, cfg)
    sched.start()
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        sched.shutdown()

if __name__=="__main__": run_scheduler_loop()
